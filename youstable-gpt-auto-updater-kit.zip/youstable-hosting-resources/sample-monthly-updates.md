### 🆕 July 2025

- Enabled Brotli compression across shared and cloud hosting plans.
- Added support for Redis 7.2.3 with persistent caching on managed servers.
- Optimized LiteSpeed default templates for WordPress staging environments.

### 🆕 August 2025

- Launched DirectAdmin pre-installed license bundle with JetBackup 5.
- Moved India SSD nodes to dual-stack IPv4/IPv6 by default.
- Improved failover DNS for Tally Cloud servers.
